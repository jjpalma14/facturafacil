<div class="footer" >
    <div class="footer-inner">
        <div class="footer-content">
            <span class="bigger-120">
                <span class="blue bolder">JPC</span>
                &copy; 2021
            </span>

            <span class="action-buttons">
                <a href="https://www.facebook.com/jhonjairo.palmacorrea" target="_blank">
                    <i class="ace-icon fa fa-facebook-square text-primary bigger-150"></i>
                </a>
            </span>
        </div>
    </div>
</div>

<a href="#" id="btn-scroll-up" class="btn-scroll-up btn btn-sm btn-inverse">
    <i class="ace-icon fa fa-angle-double-up icon-only bigger-110"></i>
</a>
</div><!-- /.main-container -->

<!-- basic scripts -->


<!--[if !IE]> -->
<script src="<?php echo base_url() . "assets/" ?>js/jquery-2.1.4.min.js"></script>
<script src="<?php echo base_url() . "assets/" ?>js/bootstrap.min.js"></script>
<script src="<?php echo base_url() . "assets/" ?>js/jquery.dataTables.min.js"></script>
<script src="<?php echo base_url() . "assets/" ?>js/jquery.dataTables.bootstrap.min.js"></script>
<script src="<?php echo base_url() . "assets/" ?>js/dataTables.buttons.min.js"></script>
<script src="<?php echo base_url() . "assets/" ?>js/buttons.flash.min.js"></script>
<script src="<?php echo base_url() . "assets/" ?>js/buttons.html5.min.js"></script>
<script src="<?php echo base_url() . "assets/" ?>js/buttons.print.min.js"></script>
<script src="<?php echo base_url() . "assets/" ?>js/buttons.colVis.min.js"></script>
<script src="<?php echo base_url() . "assets/" ?>js/dataTables.select.min.js"></script>
<script src="<?php echo base_url() . "assets/" ?>js/ace-elements.min.js"></script>
<script src="<?php echo base_url() . "assets/" ?>js/ace.min.js"></script>
<script src="<?php echo base_url() . "assets/" ?>js/funciones.js"></script>
<script src="<?php echo base_url() . "assets/" ?>js/notify.js"></script>
<script src="<?php echo base_url() . "assets/" ?>js/sweetalert2/sweetalert2.all.min.js"></script>
<script src="<?php echo base_url() . "assets/" ?>js/jquery-ui.custom.min.js"></script>
<script src="<?php echo base_url() . "assets/" ?>js/jquery.ui.touch-punch.min.js"></script>
<script src="<?php echo base_url() . "assets/" ?>js/chosen.jquery.min.js"></script>
<script src="<?php echo base_url() . "assets/" ?>js/bootstrap-datepicker.min.js"></script>
<script src="<?php echo base_url() . "assets/" ?>js/bootstrap-timepicker.min.js"></script>
<script src="<?php echo base_url() . "assets/" ?>js/moment.min.js"></script>
<script src="<?php echo base_url() . "assets/" ?>js/daterangepicker.min.js"></script>
<script src="<?php echo base_url() . "assets/" ?>js/bootstrap-datetimepicker.min.js"></script>
<script src="<?php echo base_url() . "assets/" ?>js/bootstrap-colorpicker.min.js"></script>
<script src="<?php echo base_url() . "assets/" ?>js/jquery.knob.min.js"></script>
<script src="<?php echo base_url() . "assets/" ?>js/autosize.min.js"></script>
<script src="<?php echo base_url() . "assets/" ?>js/jquery.inputlimiter.min.js"></script>
<script src="<?php echo base_url() . "assets/" ?>js/jquery.maskedinput.min.js"></script>
<script src="<?php echo base_url() . "assets/" ?>js/bootstrap-tag.min.js"></script>




</body>
</html>


